#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    gui.setup();
    gui.add(sinParam.set("SINE",0.0,0.0,300.0));
    gui.add(cosParam.set("COSINE",0.0,0.0,300.0));
    
    w = ofGetWidth();
    h = ofGetHeight();
    vid.initGrabber(w,h,true);
}

//--------------------------------------------------------------
void ofApp::update(){
    
    sine = sin(ofGetElapsedTimef()*2.0) * sinParam;
    cose = cos(ofGetElapsedTimef()*2.0) * cosParam;
    
    ofSetWindowTitle(ofToString(ofGetFrameRate()));
    vid.update();

}

//--------------------------------------------------------------
void ofApp::draw(){
    
    gui.draw();
    
    ofBackground(0,0,0);
    ofSetColor(255,255,255);
    
    ofRectangle(20,20,0,0);
    ofSetColor(255,255,255);
    
    for (int y=0; y<h; y+=10) {
        for (int x=0; x<w; x+=10) {
            
            int i = (y*w+x)*3;
            int r = vid.getPixels()[i+0];
            int g = vid.getPixels()[i+1];
            int b = vid.getPixels()[i+2];
            
            //calculatin Brightness
            float br = (r+b+g) / 765.0;
    
            ofSetColor(ofColor::fromHsb(br*255,255,255));
            
            //calculating the brightness and mutiplying by sin-cos
            float co = cos(br*TWO_PI);
            float si = sin(br*TWO_PI);
            
            //drawing lines based on the GUI
            ofLine(x-5*co, y-5*si, x+(5*sine)*co, y+(5*cose)*si);
        }
    }


}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){


    

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
