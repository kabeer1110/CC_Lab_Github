#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    
    ofBackground(255);
    
    gui.setup();
    gui.add(scale.set("SIZE", 0, 0, 255));
    gui.add(circleResolution.setup("Polygon Sides", 5, 3, 90));
    gui.add(red.set("Red Value", 0, 0, 255));
    gui.add(green.set("Green Value", 0, 0, 255));
    gui.add(blue.set("Blue Value", 0, 0, 255));
    gui.add(alpha.set("Opacity", 0, 0, 255));

    fbo.allocate(1280,720);
    fbo.begin();
    ofClear(255);
    fbo.end();
    

}

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
void ofApp::draw(){
    fbo.draw(0, 0);
    gui.draw();
    

}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    fbo.begin();
    ofPushStyle();
    ofSetColor(red, green, blue, alpha);
    ofDrawCircle(mouseX, mouseY, scale);
    ofPopStyle();
    fbo.end();
    
    
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
