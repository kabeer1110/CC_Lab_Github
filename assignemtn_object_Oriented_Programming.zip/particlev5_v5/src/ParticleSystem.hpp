//
//  ParticleSystem.hpp
//  particlev5_v5
//
//  Created by Kabeer on 11/8/16.
//
//

#include <stdio.h>

#pragma once
#include "ofMain.h"
#include "Particle.hpp"

class ParticleSystem{
public:
    ParticleSystem(ofVec2f position);
    void update(ofVec2f force);
    void draw();
    
    
    vector<Particle>    mParticleList;
    ofVec2f             mPosition;
    int                 mEmitRate;
    bool                mIsAddingParticles;
    
};
