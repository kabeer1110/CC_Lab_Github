#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){

    gui.setup();
    gui.add(sinParam.set("SINE",0.0,0.0,300.0));
    gui.add(cosParam.set("COSINE",0.0,0.0,300.0));
    gui.add(posParam.set("POSITION",0.0,0.0,10.0));
    
    ofBackground(0);
    mGravity = ofVec2f(0.f, 0.02f);
    
}

//--------------------------------------------------------------
void ofApp::update(){
    sine = sin(ofGetElapsedTimef()*2.0) * sinParam;
    cose = cos(ofGetElapsedTimef()*2.0) * cosParam;
    position = posParam;
    
    for (int i = 0; i < mSystems.size(); i++) {
        // apply gravity to all particles
        mSystems[i].update(mGravity*(sine * cos(ofGetElapsedTimef()* cose)));}
}

//--------------------------------------------------------------
void ofApp::draw(){
    
    gui.draw();
    
    for (int i = sine * sin(ofGetElapsedTimef()*2); i < mSystems.size(); i++) {
        // draw particle systems
        //mSystems[i].draw();}
        mSystems[i].draw();}
    
    ofTranslate(ofGetWidth()/position, ofGetHeight()/position);
    ofSetColor( ofColor( ofRandom( 0, 255),  ofRandom( 100, 255 ), ofRandom( 0, 255 ) ));
    
    ofCircle(sine * sin(ofGetElapsedTimef() * 3), cose * cos(ofGetElapsedTimef() * 5), 50);

}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
    ParticleSystem system(ofVec2f(x, y));
    
    mSystems.push_back(system);
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){
    ofClearAlpha();

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
